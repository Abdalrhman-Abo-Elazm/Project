
(function ($) {
	'use strict';

    // $(window).on('load', function(){
    //     $("#preloader").addClass("hide");
    // })
	$(document).ready(function () {
        setTimeout(function() {
            $('#preloader').addClass('hide');
        }, 1000);
	});

})(jQuery);
	